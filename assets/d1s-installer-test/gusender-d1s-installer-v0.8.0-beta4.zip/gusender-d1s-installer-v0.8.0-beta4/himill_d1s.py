#!/usr/bin/env python3
"""
himill_d1s.py — Interactive installer/maintenance menu for the HiMill D1S.

Bundled in the gusender-d1s-installer release. Wraps himill_flash.py
(flash, wifi-setup, wifi-status) with a friendly menu, plus two new
items: install/update sender, and apply default D1S settings.

Run with no args to get the menu, or with a numbered subcommand for
scripted use:

    python himill_d1s.py            # interactive menu
    python himill_d1s.py 3           # flash STM32 firmware
    python himill_d1s.py sender      # install sender (named alias)
"""

import json
import pathlib
import sys
import time
import urllib.parse

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    sys.exit("pyserial required: pip install -r requirements.txt")

try:
    import requests
except ImportError:
    sys.exit("requests required: pip install -r requirements.txt")

import himill_flash


HERE = pathlib.Path(__file__).resolve().parent
FW_DIR = HERE / "firmware"
SENDER_DIR = HERE / "sender"


def find_firmware(pattern):
    """Locate a firmware file in firmware/ by glob; bail with a clear msg
    if it's missing (the bundle is broken)."""
    matches = sorted(FW_DIR.glob(pattern))
    if not matches:
        sys.exit(f"Firmware file not found: {FW_DIR}/{pattern}\n"
                 "The installer bundle is incomplete.")
    return matches[0]


def find_sender_files():
    """Locate the gusender-v*.js.gz bundle + index.html in sender/.
    Returns (bundle_path, index_path)."""
    bundles = sorted(SENDER_DIR.glob("gusender-v*.js.gz"))
    index = SENDER_DIR / "index.html"
    if not bundles or not index.exists():
        sys.exit(f"Sender files not found in {SENDER_DIR}/\n"
                 "The installer bundle is incomplete.")
    return bundles[0], index


def find_grblhal_bin():
    return find_firmware("grblhal-d1s*.bin")


def find_esp3d_bin():
    return find_firmware("esp3d-firmware*.bin")


def find_defaults_json():
    p = HERE / "defaults" / "d1s-default-settings.json"
    if not p.exists():
        sys.exit(f"Default settings file not found: {p}\n"
                 "The installer bundle is incomplete.")
    return p


# ---------------------------------------------------------------------------
# Menu item 1 — install/update sender
# ---------------------------------------------------------------------------

def install_sender():
    """Upload the sender's gusender-vX.Y.Z-HASH.js.gz + index.html to
    the ESP3D over HTTP (same path EGSender's bin/deploy.sh uses for
    field installs)."""

    print("\n=== Install/update sender ===\n")
    host = input("ESP3D IP address (e.g. 192.168.1.114): ").strip()
    if not host:
        print("Cancelled.")
        return
    if "://" not in host:
        host = "http://" + host
    base = host.rstrip("/")

    bundle, index = find_sender_files()
    print(f"\nUsing bundle: {bundle.name}")

    print(f"→ Uploading {bundle.name} to {base}/sdfiles")
    try:
        with bundle.open("rb") as f:
            r = requests.post(
                f"{base}/sdfiles",
                data={"path": "/"},
                files={"file": (bundle.name, f, "application/octet-stream")},
                timeout=30,
            )
        r.raise_for_status()
    except requests.RequestException as e:
        sys.exit(f"Upload failed: {e}")

    print(f"→ Uploading index.html to {base}/files")
    try:
        with index.open("rb") as f:
            r = requests.post(
                f"{base}/files",
                files={"file": ("index.html", f, "text/html")},
                timeout=10,
            )
        r.raise_for_status()
    except requests.RequestException as e:
        sys.exit(f"Upload failed: {e}")

    print("\n✓ Sender installed.")
    print(f"  Open {base}/ in your browser.")
    print("  Clear IndexedDB cache if same version was previously cached.")


# ---------------------------------------------------------------------------
# Menu items 2-5 — wrap himill_flash.py subcommands
# ---------------------------------------------------------------------------

def flash_esp3d():
    print("\n=== Flash ESP3D (WiFi) firmware ===\n")
    host = input("ESP3D IP address (e.g. 192.168.1.114): ").strip()
    if not host:
        print("Cancelled.")
        return
    pwd = input("ESP3D admin password (blank if none): ").strip() or None

    bin_path = find_esp3d_bin()
    print(f"\nUsing firmware: {bin_path.name}")
    print("This will reboot the ESP3D — the WiFi will drop momentarily.")

    if not confirm("Proceed?"):
        return

    argv = ["--host", host, str(bin_path)]
    if pwd:
        argv = ["--password", pwd] + argv
    himill_flash.main_esp3d(argv)


def flash_stm32():
    print("\n=== Flash STM32 (grblHAL) firmware ===\n")
    print("Required: USB cable from D1S to this computer.")
    print("The flash takes ~30 seconds. Do not unplug.")

    if not confirm("Proceed?"):
        return

    bin_path = find_grblhal_bin()
    print(f"\nUsing firmware: {bin_path.name}")
    himill_flash.main_stm32([str(bin_path)])


def configure_wifi():
    print("\n=== Configure WiFi SSID ===\n")
    print("Required: USB cable from D1S to this computer.")
    if not confirm("Proceed?"):
        return
    himill_flash.main_wifi_setup([])


def show_wifi_status():
    print("\n=== Current WiFi status ===\n")
    print("Required: USB cable from D1S to this computer.")
    if not confirm("Proceed?"):
        return
    himill_flash.main_wifi_status([])


# ---------------------------------------------------------------------------
# Menu item 6 — apply default D1S settings
# ---------------------------------------------------------------------------

def apply_defaults():
    """Apply the bundled D1S defaults via grblHAL $N=value commands.

    Strategy (mirrors EGSender's pessimistic write-then-read):
      1. Connect over USB serial (auto-detect via VID:PID)
      2. Read all current settings via $$
      3. Compute diff (current → default)
      4. Show diff, ask y/n
      5. Send $N=value for each changed setting
      6. Re-read $$ to verify
    """
    print("\n=== Apply default D1S settings ===\n")
    print("Required: USB cable from D1S to this computer.")
    print("This will overwrite machine settings ($N values) on the controller.")
    print("WCS offsets, tool length, and G92 are NOT touched.\n")

    defaults_file = find_defaults_json()
    with defaults_file.open() as f:
        defaults = json.load(f)["settings"]
    print(f"Default profile: {len(defaults)} settings from {defaults_file.name}")

    if not confirm("Continue?"):
        return

    port = himill_flash.find_port()
    print(f"\n→ Reading current settings from {port}")
    diff = _compute_settings_diff(port)

    if not diff:
        print("\n✓ All settings already match defaults. Nothing to do.")
        return

    print(f"\n{len(diff)} settings will change:\n")
    print(f"  {'$ID':<6} {'CURRENT':<14} → {'DEFAULT':<14}  {'KIND'}")
    for sid, have, want, kind in diff:
        have_str = "(missing)" if have is None else have
        print(f"  ${sid:<5} {have_str:<14} → {want:<14}  {kind}")

    if not confirm("\nApply these changes?"):
        return

    _write_and_verify_settings(port, diff)


def reset_and_apply_defaults():
    """First-time setup after flashing grblHAL onto a stock MaxMake D1S.

    Sends $RST=* over USB to wipe all controller state (settings + WCS
    offsets + tool table), then applies our default $N profile. Use after
    a fresh grblHAL flash; do NOT use during normal operation — it will
    erase the work zero of an already-set-up machine.
    """
    print("\n=== Reset controller + apply default settings ===\n")
    print("Required: USB cable from D1S to this computer.")
    print()
    print("This will:")
    print("  1. Send $RST=* — wipes settings, WCS offsets (G54-G59),")
    print("     tool table, and G92 — full factory reset.")
    print("  2. Apply our default D1S grblHAL settings profile.")
    print()
    print("After this you'll need to re-zero your machine before running jobs.")
    print()
    print("Use this ONCE, right after flashing grblHAL onto a stock D1S.")
    print("Do NOT use it on an already-configured machine.\n")

    if not confirm("Wipe controller state and apply defaults?"):
        return

    port = himill_flash.find_port()

    print(f"\n→ Sending $RST=* to {port}")
    with serial.Serial(port, baudrate=115200, timeout=2) as ser:
        ser.dtr = True
        time.sleep(0.5)
        ser.reset_input_buffer()
        ser.write(b"$RST=*\n")
        ser.flush()
        reply = _read_until_ok_or_error(ser, timeout=5.0)
        if "error" in reply.lower():
            sys.exit(f"  $RST=* failed: {reply.strip()}")
        print(f"  controller said: {reply.strip()}")

    print("\n→ Power-cycling check: please toggle the D1S power off and back on,")
    print("  then press Enter when the controller is fully booted.")
    try:
        input("  Press Enter when ready, or Ctrl-C to skip: ")
    except (EOFError, KeyboardInterrupt):
        print("\n  (proceeding without power cycle)")

    # Re-find the port — it may have re-enumerated.
    port = himill_flash.find_port()
    print(f"  reconnected to {port}\n")

    # No outer confirm here — the user already opted in. Apply everything
    # the bundle's profile specifies, including settings that already
    # happen to match the freshly-reset compiled defaults.
    diff = _compute_settings_diff(port)
    _write_and_verify_settings(port, diff)


def _compute_settings_diff(port):
    """Read current settings + bundled defaults, return list of
    (sid, current, default, kind) tuples for everything that needs to
    change."""
    defaults_file = find_defaults_json()
    with defaults_file.open() as f:
        defaults = json.load(f)["settings"]

    current = read_grblhal_settings(port)

    diff = []
    for sid, want in defaults.items():
        if want == "":
            continue
        have = current.get(sid)
        if have is None:
            diff.append((sid, None, want, "NEW"))
        elif not _values_equal(have, want):
            diff.append((sid, have, want, "CHANGE"))
    return diff


def _write_and_verify_settings(port, diff):
    """Write the diff to the controller, then re-read and verify."""
    if not diff:
        print("\n✓ All settings already match defaults. Nothing to do.")
        return

    print(f"\n→ Writing {len(diff)} settings")
    failed = []
    with serial.Serial(port, baudrate=115200, timeout=2) as ser:
        ser.dtr = True
        time.sleep(0.5)
        ser.reset_input_buffer()
        for sid, _, want, _ in diff:
            line = f"${sid}={want}\n"
            ser.write(line.encode("ascii"))
            ser.flush()
            reply = _read_until_ok_or_error(ser, timeout=2.0)
            if "error" in reply.lower():
                failed.append((sid, want, reply.strip()))
                print(f"  ${sid}={want}  FAILED ({reply.strip()})")
            else:
                print(f"  ${sid}={want}  ok")

    print("\n→ Re-reading settings to verify")
    after = read_grblhal_settings(port)
    mismatches = []
    for sid, _, want, _ in diff:
        got = after.get(sid)
        if got is None or not _values_equal(got, want):
            mismatches.append((sid, want, got))

    if failed or mismatches:
        print(f"\n⚠ {len(failed)} write errors, {len(mismatches)} verify mismatches")
        for sid, want, err in failed:
            print(f"  ${sid}={want}: {err}")
        for sid, want, got in mismatches:
            print(f"  ${sid}: wanted {want}, controller has {got}")
        print("\n  Some settings may have been coerced/clamped by grblHAL.")
    else:
        print("\n✓ All settings applied and verified.")


def _values_equal(a, b):
    """grblHAL formats floats canonically — '400' vs '400.000' should
    compare equal. Try numeric first, fall back to string."""
    try:
        return float(a) == float(b)
    except (ValueError, TypeError):
        return str(a).strip() == str(b).strip()


def _read_until_ok_or_error(ser, timeout):
    deadline = time.time() + timeout
    buf = bytearray()
    while time.time() < deadline:
        chunk = ser.read(256)
        if chunk:
            buf.extend(chunk)
            text = buf.decode("utf-8", errors="replace")
            if "ok" in text.lower() or "error" in text.lower():
                return text
        else:
            time.sleep(0.02)
    return buf.decode("utf-8", errors="replace")


def read_grblhal_settings(port):
    """Send $$ and parse '$N=value' lines until ok arrives."""
    settings = {}
    with serial.Serial(port, baudrate=115200, timeout=2) as ser:
        ser.dtr = True
        time.sleep(0.5)
        ser.reset_input_buffer()
        ser.write(b"$$\n")
        ser.flush()

        deadline = time.time() + 5.0
        buf = bytearray()
        while time.time() < deadline:
            chunk = ser.read(512)
            if chunk:
                buf.extend(chunk)
                text = buf.decode("utf-8", errors="replace")
                if text.strip().endswith("ok"):
                    break
            else:
                time.sleep(0.03)
        else:
            print("  warning: $$ did not return 'ok' within 5s; "
                  "parsing what we got")

        text = buf.decode("utf-8", errors="replace")
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("$") and "=" in line:
                sid, _, value = line[1:].partition("=")
                settings[sid.strip()] = value.strip()

    return settings


# ---------------------------------------------------------------------------
# Menu plumbing
# ---------------------------------------------------------------------------

MENU = [
    ("Install/update sender",                       install_sender),
    ("Flash ESP3D (WiFi) firmware",                 flash_esp3d),
    ("Flash STM32 (grblHAL) firmware",              flash_stm32),
    ("Configure WiFi SSID",                         configure_wifi),
    ("Show current WiFi SSID + IP",                 show_wifi_status),
    ("Apply default D1S settings",                  apply_defaults),
    ("Reset controller + apply defaults (post-flash)", reset_and_apply_defaults),
]

ALIASES = {
    "sender":     1, "install":    1, "update":     1,
    "esp3d":      2, "wifi-flash": 2,
    "stm32":      3, "grblhal":    3, "flash":      3,
    "wifi":       4, "wifi-setup": 4,
    "status":     5, "wifi-status":5,
    "defaults":   6, "settings":   6,
    "reset":      7, "factory":    7, "first-time": 7,
}


def confirm(prompt):
    answer = input(f"{prompt} [y/N]: ").strip().lower()
    return answer in ("y", "yes")


def show_menu():
    print("\n" + "=" * 50)
    print("  HiMill D1S installer — gusender bundle")
    print("=" * 50 + "\n")
    for idx, (label, _) in enumerate(MENU, start=1):
        print(f"  {idx}. {label}")
    print("  q. Quit\n")


def run_choice(choice):
    if choice in ("q", "quit", "exit"):
        return False
    if choice.isdigit():
        idx = int(choice)
        if 1 <= idx <= len(MENU):
            try:
                MENU[idx - 1][1]()
            except KeyboardInterrupt:
                print("\n  (cancelled)")
            except SystemExit as e:
                if e.code:
                    print(f"\n  ✖ {e}")
            return True
    if choice in ALIASES:
        return run_choice(str(ALIASES[choice]))
    print(f"  Unknown choice: {choice!r}")
    return True


def main():
    if len(sys.argv) > 1:
        # Scripted use: himill_d1s.py 3, himill_d1s.py sender
        run_choice(sys.argv[1].lower())
        return

    while True:
        show_menu()
        try:
            choice = input("Choose: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nbye")
            return
        if not run_choice(choice):
            return


if __name__ == "__main__":
    main()
