#!/bin/bash
# Linux/macOS launcher for the HiMill D1S installer.
set -e
cd "$(dirname "$0")"
exec python3 himill_d1s.py "$@"
