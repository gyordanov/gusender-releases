GUSender v0.8.0-beta4 — ESP3D / HiMill D1S Installation
======================================================

Files in this package:
  index.html              Loader (4 KB) — goes in controller flash (/FS)
  gusender-v0.8.0-beta4-a817fe2.js.gz   App bundle (~380 KB) — goes in SD card root

How it works:
  The loader (index.html) is stored on the controller's flash memory.
  When you open the controller's IP in a browser, the loader downloads
  the app from the internet, decompresses it, and caches it in the
  browser. Subsequent loads are instant from cache.

  If the internet is unavailable, the loader offers two fallback options:
  - Upload the .js.gz file from your computer (drag & drop)
  - Load from the SD card copy (included in this package)
    Note: loading from SD during a running job may interrupt it!

  Machine config and macros are stored on the controller's flash (/FS),
  NOT on the SD card. This means config reads are safe during SD card
  jobs — refreshing the browser won't kill a running job.

Installation:
  1. Copy gusender-v0.8.0-beta4-a817fe2.js.gz to the ROOT of the SD card
  2. Upload index.html to the controller's flash filesystem (/FS)
     (this replaces the default ESP3D web interface)
  3. Open a browser and navigate to http://<controller-ip>/
  4. First load downloads and caches the app from the internet
  5. A setup form will appear on first visit — review settings and click Save

Install via command line (replace IP with your controller's address):
  curl -F 'path=/' -F 'file=@gusender-v0.8.0-beta4-a817fe2.js.gz' http://<IP>/sdfiles
  curl -F 'path=/' -F 'file=@index.html;filename=index.html' http://<IP>/files

Updating:
  Upload ALL files from the new release zip (same steps as installation).
  Your machine config (gusender-config.json on flash) is preserved automatically.

Troubleshooting:
  - If the page shows "server unavailable" on first load, your machine
    may not have internet access. Use the "Upload from PC" button and
    select the gusender-v0.8.0-beta4-a817fe2.js.gz file from this package.
  - If you see "Error 62: Failed to open directory", the SD card mount
    was lost. Click Refresh in the SD Card panel or reload the page.
  - Config is shared across all browsers. If you change settings in
    Chrome, Firefox will see the same changes on next connect.
  - Refreshing the browser during an SD card job is safe — config and
    the app bundle are loaded from flash and browser cache, not SD.
