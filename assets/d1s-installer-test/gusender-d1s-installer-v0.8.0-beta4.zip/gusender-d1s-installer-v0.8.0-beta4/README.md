# HiMill D1S installer

Bundle of firmware + sender + tooling for the [HiMill D1S](https://himill.com/)
running [gusender](https://fs.platformis.com/gus/). Run the menu to install or
update any of:

1. **Install/update sender** — uploads the gusender web app to the ESP3D over WiFi
2. **Flash ESP3D (WiFi) firmware** — GUSender's D1S ESP3D build over WiFi (HTTP)
3. **Flash STM32 (grblHAL) firmware** — our grblHAL build over USB
4. **Configure WiFi SSID** — scan + connect, over USB
5. **Show current WiFi SSID + IP** — query the ESP3D, over USB
6. **Apply default D1S settings** — write a known-good `$N` profile, over USB
7. **Reset controller + apply defaults (post-flash)** — `$RST=*` then write
   the default profile. Use ONCE after first grblHAL flash; do not use on a
   set-up machine (it wipes WCS offsets, tool table, and G92).

Items 3-7 need the D1S USB cable plugged into the computer. Items 1-2 need the
D1S to already be on WiFi (item 4 gets you there).

## v0.7.6 rotation test build

This bundle includes the current grblHAL D1S firmware used for GUSender's
workpiece rotation testing. In the sender, measuring rotation only arms the
angle; the firmware rotation is applied when a job starts and can be cleared
from the rotation indicator above the DRO.

For first tests, run an air-cut with the bit removed and use simple slot or
contour G-code before cutting stock. If firmware rotation is active, the sender
blocks probe moves until rotation is cleared.

## First-time setup (coming from stock MaxMake)

Run in this order:

1. Item **4** — configure WiFi (USB).
2. Item **2** — flash ESP3D/WiFi firmware (uses the IP from step 1).
3. Item **3** — flash grblHAL firmware (USB).
4. Power-cycle the D1S.
5. Item **7** — reset controller + apply defaults (USB).
6. Item **1** — install sender (uses the IP from step 1).
7. Open `http://<controller-ip>/` in a browser.

**Do not skip either firmware update.** The bundled ESP3D/WiFi firmware and the
bundled grblHAL firmware are a matched pair. The new grblHAL D1S firmware relies
on the new ESP3D bridge behavior, and the D1S is not considered installed or
supported until **both** firmwares have been flashed and verified. Mixing the new
grblHAL firmware with older stock ESP3D firmware can make the sender fail to load
or communicate reliably, and may look like the controller is stuck.

You'll need to re-zero your machine after step 5 — `$RST=*` wipes WCS offsets.

## Install

### Linux

```bash
pip install -r requirements.txt
./himill_d1s.sh
```

If the launcher fails with "permission denied", run `chmod +x himill_d1s.sh`.

Most distros ship Python 3.10+; if not, install via your package manager.

### macOS

Python 3 ships with macOS, but if you don't have it:

```bash
brew install python
```

Then:

```bash
pip3 install -r requirements.txt
./himill_d1s.sh
```

If the launcher fails with "permission denied", run `chmod +x himill_d1s.sh`.

### Windows

1. Install Python 3.10+ from https://www.python.org/downloads/.
   **Check "Add Python to PATH"** during install — this matters.
2. Open PowerShell or CMD in this folder.
3. Install requirements:
   ```
   pip install -r requirements.txt
   ```
4. Run the menu:
   ```
   himill_d1s.bat
   ```
   …or double-click `himill_d1s.bat` in Explorer.

The Maxmake CDC bootloader appears as a generic USB serial device on
Windows 10/11 — no driver install needed. If the D1S doesn't show up,
open Device Manager → look for "USB Serial Device" under Ports.

## Usage

Run with no args for the interactive menu:

```
python himill_d1s.py
```

Or jump straight to a menu item:

```
python himill_d1s.py 3            # flash STM32 firmware
python himill_d1s.py sender       # install sender
python himill_d1s.py settings     # apply default settings
```

## Bundle contents

```
himill_d1s.py                    # menu wrapper
himill_flash.py                  # flash + WiFi protocol logic
himill_d1s.sh / .bat             # launchers
requirements.txt                 # pyserial, requests, pyusb
README.md                        # this file
firmware/
  grblhal-d1s-<sha>.bin          # grblHAL rotation-test build for the D1S
  esp3d-firmware*.bin            # GUSender's D1S ESP3D/WiFi firmware
sender/
  gusender-v*.js.gz              # gusender web app bundle
  index.html                     # gusender entry page
defaults/
  d1s-default-settings.json      # known-good $N values for the D1S
```

## Notes

- This bundle is in **testing**. If you hit a wall, open an issue at the
  EGSender repo with the OS, Python version, and whatever the script printed.
- Default settings exclude WCS offsets, tool length, and G92 — those are
  machine-specific and would clobber the values you've zeroed for *your* D1S.
- The grblHAL D1S firmware source is published at
  https://github.com/gyordanov/STM32F1xx.
