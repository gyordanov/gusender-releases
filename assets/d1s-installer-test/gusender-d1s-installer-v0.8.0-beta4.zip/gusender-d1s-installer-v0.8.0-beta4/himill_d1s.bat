@echo off
REM Windows launcher for the HiMill D1S installer.
cd /d "%~dp0"
python himill_d1s.py %*
