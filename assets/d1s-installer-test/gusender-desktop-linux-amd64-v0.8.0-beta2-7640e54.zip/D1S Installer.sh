#!/usr/bin/env sh
set -e
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$DIR/gusender-desktop" --mode d1s-installer "$@"
