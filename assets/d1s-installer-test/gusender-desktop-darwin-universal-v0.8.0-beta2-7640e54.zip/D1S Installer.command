#!/usr/bin/env sh
set -e
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -n "d1s-installer" ]; then
  open "$DIR/gusender-desktop.app" --args --mode "d1s-installer"
else
  open "$DIR/gusender-desktop.app" --args
fi
