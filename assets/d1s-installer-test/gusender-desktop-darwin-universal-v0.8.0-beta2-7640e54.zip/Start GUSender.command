#!/usr/bin/env sh
set -e
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -n "" ]; then
  open "$DIR/gusender-desktop.app" --args --mode ""
else
  open "$DIR/gusender-desktop.app" --args
fi
