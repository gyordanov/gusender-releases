#!/usr/bin/env sh
set -e
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -n "sender-updater" ]; then
  open "$DIR/gusender-desktop.app" --args --mode "sender-updater"
else
  open "$DIR/gusender-desktop.app" --args
fi
