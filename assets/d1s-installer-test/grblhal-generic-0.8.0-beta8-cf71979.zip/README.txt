GUSender v0.8.0-beta8 — FlexiHAL / grblHAL Installation
======================================================

Files in this package:
  index.html.gz           Loader (4 KB) — goes in SD card /www folder
  gusender-v0.8.0-beta8-cf71979.js.gz   App bundle (~380 KB) — goes in SD card root

How it works:
  The loader (index.html.gz) is served by your controller when you open
  its IP in a browser. On first load, it downloads the app from the
  internet, decompresses it, and caches it in the browser. Subsequent
  loads are instant from cache — no network or SD card access needed.

  If the internet is unavailable, the loader offers two fallback options:
  - Upload the .js.gz file from your computer (drag & drop)
  - Load from the SD card copy (included in this package)

  Machine config and macros are stored on the SD card as
  /www/gusender-config.json. Any browser on the network reads the same
  config — no per-browser setup needed.

Installation:
  1. Copy gusender-v0.8.0-beta8-cf71979.js.gz to the ROOT of the SD card
  2. Copy index.html.gz into the /www folder on the SD card
     (create the /www folder if it doesn't exist)
  3. Insert the SD card and power on the controller
  4. Open a browser and navigate to http://<controller-ip>/
  5. A setup form will appear on first visit — review settings and click Save

Or install via command line (replace IP with your controller's address):
  curl -F 'path=/'    -F 'file=@gusender-v0.8.0-beta8-cf71979.js.gz' http://<IP>/sdfiles
  curl -F 'path=/www' -F 'file=@index.html.gz;filename=index.html.gz' http://<IP>/sdfiles

Updating:
  Upload ALL files from the new release zip (same steps as installation).
  Your machine config (gusender-config.json) is preserved automatically.

Troubleshooting:
  - If the page shows "server unavailable" on first load, your machine
    may not have internet access. Use the "Upload from PC" button and
    select the gusender-v0.8.0-beta8-cf71979.js.gz file from this package.
  - If you see "Error 62: Failed to open directory", the SD card mount
    was lost. Click Refresh in the SD Card panel or reload the page.
  - Config is shared across all browsers. If you change settings in
    Chrome, Firefox will see the same changes on next connect.
