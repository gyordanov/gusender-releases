@echo off
set "DIR=%~dp0"
"%DIR%gusender-desktop.exe" --mode sender-updater %*
