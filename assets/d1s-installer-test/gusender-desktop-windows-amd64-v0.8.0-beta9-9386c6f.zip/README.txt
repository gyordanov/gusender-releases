GUSender Desktop 0.8.0-beta9

This package contains one real desktop binary/app and simple launch shortcuts.

Launchers:
  - Start GUSender: opens the normal desktop sender launcher.
  - D1S Installer: opens the guided HiMill D1S installer.
  - Sender Updater: opens the HTTP sender updater/recovery tool.

The D1S installer uses the GitHub beta release channel by default:
https://raw.githubusercontent.com/gyordanov/gusender-releases/main/channels/d1s-installer-test.json

Keep the launcher files next to the binary/app.
